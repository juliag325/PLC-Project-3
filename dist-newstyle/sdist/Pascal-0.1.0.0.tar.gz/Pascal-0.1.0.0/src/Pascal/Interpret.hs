module Pascal.Interpret 
(
    interpret
)
where

import Pascal.Data
import Pascal.Map as Map
import qualified Data.StringMap as StringMap
import Flow

-- TODO: define auxiliary functions to aid interpretation
-- Feel free to put them here or in different modules
-- Hint: write separate evaluators for numeric and
-- boolean expressions and for statements

-- make sure you write test unit cases for all functions


{-getIdValueR:: String -> Float

getIdValueS:: String -> String

getIdValueB:: String -> Bool-}



realExp :: Exp -> Float
realExp (Op2 "+" e1 e2) = (realExp e1) + (realExp e2)
realExp (Op2 "-" e1 e2) = (realExp e1) - (realExp e2)
realExp (Op2 "/" e1 e2) = (realExp e1) / (realExp e2)
realExp (Op2 "*" e1 e2) = (realExp e1) * (realExp e2)
realExp (Op2 _ _ _) = error("Stack underflow")

realExp (Op1 "-" e1) = 0 - (realExp e1)

realExp (Op3 "sin" e1) = sin (realExp e1)
realExp (Op3 "cos" e1) = cos (realExp e1)
realExp (Op3 "exp" e1) = exp (realExp e1)
realExp (Op3 "sqrt" e1) = sqrt (realExp e1)
realExp (Op3 "ln" e1) = log (realExp e1)

realExp (Real e1) = e1
realExp (IntR e1) = fromIntegral e1

--realExp (Var String e1) = 

realExp _ = error("error")

booleanExp :: BoolExp -> Bool
booleanExp (OpB "and" b1 b2) = (booleanExp b1) && (booleanExp b2)
booleanExp (OpB "or" b1 b2) = (booleanExp b1) || (booleanExp b2)
booleanExp (Not b1) = not (booleanExp b1)
booleanExp (Comp "=" e1 e2) = (realExp e1) == (realExp e2)
booleanExp (Comp "<>" e1 e2) = (realExp e1) /= (realExp e2)
booleanExp (Comp ">" e1 e2) = (realExp e1) > (realExp e2)
booleanExp (Comp "<" e1 e2) = (realExp e1) < (realExp e2)
booleanExp (Comp "<=" e1 e2) = (realExp e1) <= (realExp e2)
booleanExp (Comp ">=" e1 e2) = (realExp e1) >= (realExp e2)

booleanExp (Boolean b1) = b1
--booleanExp (VarB String b1) = -}
{-while :: BoolExp -> Statement -> String
while b s = 
    let loop = do evalStatements s in 
    if (booleanExp b) then loop else []-}

writeln :: String -> String
writeln s = s 

evalStatements ::  Statement -> String
evalStatements (IO "writeln" s) = concat (map writeln s)
evalStatements (EvalR e) = show (realExp e)
evalStatements (EvalB e) = show (booleanExp e)
evalStatements (Block s) = concat (map evalStatements s )
--evalStatements (While b s) v = if booleanExp b then while b s else [];
evalStatements (If b s1 s2) = if (booleanExp b) then (evalStatements s1 ) else (evalStatements s2 )
--evalStatements (AssignR s e) = let s = realExp e

interpret :: Program -> Statement -> String
-- TODO: write the interpreter
interpret program = evalStatements (x:program)
    --let var = []
    --statement = map passVar statements
    --in concat (map evalStatements statements)

interpret _ = "Not implemented"