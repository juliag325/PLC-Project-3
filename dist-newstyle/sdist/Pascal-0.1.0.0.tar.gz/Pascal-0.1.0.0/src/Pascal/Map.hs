module Pascal.Map (
    Map
) 
where

import qualified Data.StringMap as StringMap

data Map m = StringMap m